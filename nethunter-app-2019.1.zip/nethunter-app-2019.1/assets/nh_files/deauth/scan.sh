iwlist $1 scanning | grep 'Channel\|ESSID'
